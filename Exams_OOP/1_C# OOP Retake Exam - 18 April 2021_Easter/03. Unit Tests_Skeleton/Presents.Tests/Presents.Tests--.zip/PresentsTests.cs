﻿namespace Presents.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class PresentsTests
    {
        private Bag bag;
        private Present present;

        [SetUp]

        public void SetUp()
        {
            this.bag = new Bag();
            this.present = new Present("Presure", 14.0);
        }

        [Test]

        public void Create_ShouldThrowExceptoinIfPresentIsNull()
        {
            present = null;
            Assert.Throws<ArgumentNullException>(() => bag.Create(present));
        }

        [Test]

        public void Create_ShouldThrowExceptoinIfPresentIsExists()
        {
            bag.Create(present);
            Assert.Throws<InvalidOperationException>(() => bag.Create(present));
        }

        [Test]
        public void Create_ShouldAddPresentCorectly()
        {
            bag.Create(present);
            Present expestedPresent = present;
            Assert.AreEqual(expestedPresent, bag.GetPresent(present.Name));
        }

        [Test]
        public void Create_ShouldReturnSucsessMessage()
        {
            string expectedMessage = $"Successfully added present { present.Name}.";
            Assert.AreEqual(expectedMessage, bag.Create(present));
        }
    }
}
