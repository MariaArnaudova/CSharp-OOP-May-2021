using NUnit.Framework;
using System;

namespace BankSafe.Tests
{
    public class BankVaultTests
    {
        private BankVault valut;

        [SetUp]
        public void Setup()
        {
            valut = new BankVault();
        }

        [Test]
        public void AddItem_ShouldThrowExceptionIfNotContainsKey()
        {

            Assert.Throws<ArgumentException>(() => valut.AddItem("D1", null));

        }

        [Test]
        public void AddItem_ShouldThrowExceptionIfValueIsNotNull()
        {
            valut.AddItem("A1", new Item("Kiro", "12345"));
            Assert.Throws<ArgumentException>(() => valut.AddItem("A1", new Item("Pesho", "12345")));

        }

        [Test]
        public void AddItem_ShouldThrowExceptionIfCellExist()
        {
            valut.AddItem("A1", new Item("Pesho", "de123"));
            Assert.Throws<InvalidOperationException>(() => valut.AddItem("B1", new Item("Pesho", "de123")));

        }


        //[Test]
        //public void AddItem_ShouldSetItemSucssesfuly()
        //{
        //    valut.AddItem("A1", new Item("Pesho", "de123"));
        //    string expectedMessage= $"Item:{this.valut.VaultCells["A1"].ItemId} saved successfully!";
        //    Item expectedItem = new Item("Pesho", "de123");
        //    // Assert.That(expectedItem, Is.SameAs(this.valut.VaultCells["A1"]));
        //    Assert.AreEqual(expectedMessage, valut.AddItem("A1", new Item("Pesho", "de123")));
        //}

        [Test]
        public void Remove_ShouldThrowExceptionIfCellDoesNotExist()
        {
           
            Assert.Throws<ArgumentException>(() => valut.RemoveItem("D1", new Item("Pesho", "de123")));

        }

        [Test]
        public void Remove_ShouldThrowExceptionIfItemInCellDoesNotExist()
        {

            Assert.Throws<ArgumentException>(() => valut.RemoveItem("A1", new Item("Pesho", "de123")));

        }
    }
}