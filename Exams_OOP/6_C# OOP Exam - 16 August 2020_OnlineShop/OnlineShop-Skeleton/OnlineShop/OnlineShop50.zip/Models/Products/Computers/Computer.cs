﻿using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer : Product, IComputer
    {
        private List<IComponent> components;
        private List<IPeripheral> peripherals;

        protected Computer(int id, string manufacturer, string model, decimal price, double overallPerformance) 
            : base(id, manufacturer, model, price, overallPerformance)
        {
            this.components = new List<IComponent>();
            this.peripherals = new List<IPeripheral>();
        }

        public IReadOnlyCollection<IComponent> Components => this.components.AsReadOnly();

        public IReadOnlyCollection<IPeripheral> Peripherals => this.peripherals.AsReadOnly();

        public void AddComponent(IComponent component)
        {
            if (this.components.Contains(component))
            {
                throw new ArgumentException($"Component {component.GetType().Name} already exists in {this.GetType().Name} with Id {this.Id}.");
            }

            this.components.Add(component);
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            if (this.peripherals.Contains(peripheral))
            {
                throw new ArgumentException($"Peripheral {peripheral.GetType().Name} already exists in {this.GetType().Name} with Id {Id}.");
            }

            this.peripherals.Add(peripheral);
        }

        public IComponent RemoveComponent(string componentType)
        {
            IComponent searchedComponent = this.components.FirstOrDefault(x => x.GetType().Name == componentType);
            if (searchedComponent==null|| this.components.Count==0)
            {
                throw new ArgumentException($"Component {componentType} does not exist in {this.GetType().Name} with Id {Id}.");
            }

            this.components.Remove(searchedComponent);
            return searchedComponent;
        }

        public IPeripheral RemovePeripheral(string peripheralType)
        {

            IPeripheral searchedPeripheral = this.peripherals.FirstOrDefault(x => x.GetType().Name == peripheralType);
            if (peripheralType == null || this.peripherals.Count == 0)
            {
                throw new ArgumentException($"Component {peripheralType} does not exist in {this.GetType().Name} with Id {Id}.");
            }

            this.peripherals.Remove(searchedPeripheral);
            return searchedPeripheral;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this.ToString());
            sb.AppendLine($" Components ({this.components.Count}):");
            sb.AppendLine($"  {string.Join("",this.components.ToString())}");
            sb.AppendLine($" Peripherals ({this.peripherals.Count}); Average Overall Performance ({this.peripherals.Sum(x=>x.OverallPerformance)/this.peripherals.Count}):");
            sb.AppendLine($"  {string.Join("", this.peripherals.ToString())}");

            return sb.ToString().TrimEnd();
        }
    }
}
