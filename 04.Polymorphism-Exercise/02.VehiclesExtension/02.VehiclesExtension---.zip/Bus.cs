﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Bus : Vehicle
    {
        private const double ConditionerConsumption = 1.4;
    
        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity)
            : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
        }
        //public override double FuelConsumption => base.FuelConsumption + ConditionerConsumption;
        public override double FuelConsumption { get; set; }


        public bool IsEmpty { get; set; }
        //public void DriveBus(double distance)
        //{
        //    this.fuelConsumption -= 1.4;
        //    Drive(distance);
        //}
        public override void Drive(double distance)
        {
            if (!IsEmpty)
            {
                this.FuelConsumption += ConditionerConsumption;
            }
            base.Drive(distance);
        }
    }
}
