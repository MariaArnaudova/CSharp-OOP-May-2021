﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Models.Foods
{
    public class Seed : Food
    {
        public Seed(int quantity) 
            : base(quantity)
        {
        }
    }
}
