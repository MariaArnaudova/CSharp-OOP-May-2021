﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite.Models
{
   public enum State
    {
        inProgress =1,
        Finshed =2
    }
}
