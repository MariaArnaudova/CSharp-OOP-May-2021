﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Robot : IIdentifiable
    {
        public Robot(string name, string id)
        {
            Model = name;
            Id = id;
        }
        public string Model { get; private set; }
        public string Id { get; private set; }

        //public bool CheckToFakesId(string endNumbers)
        //{
        //    string idToString = Id.ToString();
        //    string chekedString = idToString.Substring(idToString.Length - 3);
        //    if (chekedString == endNumbers)
        //    {
        //        return true;
        //    }
        //    return  false;
        //}

    }
}
