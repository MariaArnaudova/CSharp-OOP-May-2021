﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    interface IIdentifiable
    {
        public string Id { get; }
    }
}
