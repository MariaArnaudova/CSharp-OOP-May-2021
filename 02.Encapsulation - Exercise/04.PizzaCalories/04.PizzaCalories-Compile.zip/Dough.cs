﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.PizzaCalories
{
    public class Dough
    {
        private int weight;
        public Dough(int weight)
        {
            this.Weight = weight;
        }

        public White white
        {
            get
            {
                return this.white;
            }
            set
            {
                if (value.GetType().ToString() != "white")
                {
                    throw new Exception("Invalid type of dough.");
                }
                this.white = value;
            }

        }
        public Wholegrain wholegrain { get; set; }
        public int Weight
        {
            get
            {
                return this.weight;
            }
            set
            {
                if (value < 1 || value > 200)
                {
                    throw new Exception($"Dough weight should be in the range[1..200].");
                }
                this.weight = value;
            }
        }
        public string Crispy { get; set; }
        public string Chewy { get; set; }
        public string Homemade { get; set; }


        public virtual double CalculatingCalories(string techiques)
        {
            double calories = 0;
            calories = this.Weight * 2;

            if (techiques == Crispy)
            {
                return calories = calories * 0.9;
            }
            else if (techiques == Chewy)
            {
                return calories = calories * 1.1;
            }
            else if (techiques == Homemade)
            {
                return calories = calories * 1.0;
            }
            return calories;

        }

    }
}
