﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.PizzaCalories
{
  public  class White: Dough
    {
        private const double Modifier = 1.5;

        public White(int weight) 
            : base(weight)
        {
        }

        public override double CalculatingCalories(string techiques)
        {
            double calories = 0;
            calories = this.Weight * 2* Modifier;

            if (techiques == Crispy)
            {
                return calories = calories * 0.9;
            }
            else if (techiques == Chewy)
            {
                return calories = calories * 1.1;
            }
            else if (techiques == Homemade)
            {
                return calories = calories * 1.0;
            }
            return calories;
        }
    }
}
