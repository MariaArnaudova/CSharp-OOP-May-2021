﻿using System;

namespace _04.PizzaCalories
{
    class Program
    {
        static void Main(string[] args)
        {
            Dough dougt = new Dough(100);
            dougt.CalculatingCalories(Chewy);
        }
    }
}
