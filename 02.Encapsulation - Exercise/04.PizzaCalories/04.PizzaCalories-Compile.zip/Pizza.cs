﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.PizzaCalories
{
   public class Pizza
    {
        private string name;
        private Dough dough;
        private Topping topping;

        public Pizza(string name, Dough dough, Topping topping)
        {
            this.name = name;
            this.dough = dough;
            this.topping = topping;
        }

        // name, dough and toppings
    }
}
