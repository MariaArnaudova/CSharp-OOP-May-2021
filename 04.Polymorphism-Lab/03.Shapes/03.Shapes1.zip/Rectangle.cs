﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public class Rectangle : Shape
    {
        public Rectangle(double height, double width)
        {
            Height = height;
            Width = width;
        }

        public double Height { get; set; }
        public double Width { get; set; }
        public override double CalculateArea()
        {
            double rectangleArea = 0;
            return rectangleArea = Height * Width;
        }

        public override double CalculatePerimeter()
        {
            double rectanglePerimeter = 0;
            return rectanglePerimeter = 2 * (Height+Width);
        }
        public void Draw(double height, double width)
        {
            DrawLine('*', '*');
            for (int i = 0; i < height - 2; i++)
            {
                DrawLine('*', ' ');
            }
            DrawLine('*', '*');
        }

        private string DrawLine(char bounday, char inner)
        {
            StringBuilder sb = new StringBuilder();
          sb.AppendLine($"{bounday}{new string(inner, (int)(Width - 2.0))}{bounday}");
            return sb.ToString();
        }
    }
}
