﻿using System;

internal class StartUpAttribute : Attribute
{
}