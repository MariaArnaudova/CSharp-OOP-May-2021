using NUnit.Framework;
using System;

[TestFixture]
public class AxeTests
{
    private int attack = 5;
    private int durability = 6;
    private Axe axe;
    private Dummy dummy;

    [SetUp]
    public void SetUp()
    {
        axe = new Axe(attack, durability);
        dummy = new Dummy(4, 3);
    }

    [Test]
    public void When_AxeAttackAndDurabilityProvided_ShoudBeSetCorrectly()
    {


        Assert.AreEqual(axe.AttackPoints, attack);
        Assert.AreEqual(axe.DurabilityPoints, durability);
    }

    [Test]
    public void When_AxeAttacks_ShoudLooseDurabilityPoints()
    {
        axe.Attack(dummy);
        Assert.AreEqual( durability-1, axe.DurabilityPoints);
    }

    [Test]

    public void When_AxeAttackWithDurabilityPointWithZero_ShouldThrowExeption()
    {
        Dummy dummy = new Dummy(200, 200);
        Assert.Throws<InvalidOperationException>(() => 
        {
            for (int i = 0; i < 7; i++)
            {
                axe.Attack(dummy);
            } 
        });
    }
}